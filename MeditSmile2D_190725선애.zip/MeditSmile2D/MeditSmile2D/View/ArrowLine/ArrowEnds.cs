﻿using System;

namespace MeditSmile2D.View.ArrowLine
{
    [Flags]
    public enum ArrowEnds
    {
        None = 0,
        Start = 1,
        End = 2,
        Both = 3
    }
}
